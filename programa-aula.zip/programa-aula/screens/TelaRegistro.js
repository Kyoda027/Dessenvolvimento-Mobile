import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Text } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function RegisterScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleRegister = async () => {
    if (username && password) {
      try {
        const users = JSON.parse(await AsyncStorage.getItem('users')) || [];
        const userExists = users.find(user => user.username === username);

        if (userExists) {
          setErrorMessage('Usuário já existe');
        } else {
          users.push({ username, password });
          await AsyncStorage.setItem('users', JSON.stringify(users));
          navigation.navigate('Login');
        }
      } catch (error) {
        console.error(error);
      }
    } else {
      setErrorMessage('Preencha todos os campos');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
        style={styles.input}
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      {errorMessage ? <Text style={styles.error}>{errorMessage}</Text> : null}
      <Button title="Registrar" onPress={handleRegister} />
      <Button title="Faça login" onPress={() => navigation.navigate('Login')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
  },
  error: {
    color: 'red',
    marginBottom: 10,
  },
});
